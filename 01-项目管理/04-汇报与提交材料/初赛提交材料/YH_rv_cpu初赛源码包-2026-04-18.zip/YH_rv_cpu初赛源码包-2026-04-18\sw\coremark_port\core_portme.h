/*
Copyright 2018 Embedded Microprocessor Benchmark Consortium (EEMBC)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef CORE_PORTME_H
#define CORE_PORTME_H

#include <stddef.h>

#ifndef HAS_FLOAT
/*
 * Keep the portable CoreMark path on integer-only reporting so the benchmark
 * binary stays small and smoke runs finish quickly on RV32I without an FPU.
 * Formal score reporting is derived host-side from raw ticks.
 */
#define HAS_FLOAT 0
#endif

#ifndef HAS_TIME_H
#define HAS_TIME_H 0
#endif

#ifndef USE_CLOCK
#define USE_CLOCK 0
#endif

#ifndef HAS_STDIO
#define HAS_STDIO 0
#endif

#ifndef HAS_PRINTF
#define HAS_PRINTF 0
#endif

#ifndef COMPILER_VERSION
#ifdef __GNUC__
#define COMPILER_VERSION "GCC " __VERSION__
#else
#define COMPILER_VERSION "Unknown GCC"
#endif
#endif

#ifndef COMPILER_FLAGS
#if __riscv_xlen == 64
#define COMPILER_FLAGS "-O2 -march=rv64i_zicsr -mabi=lp64"
#else
#define COMPILER_FLAGS "-O2 -march=rv32i_zicsr -mabi=ilp32"
#endif
#endif

#ifndef MEM_LOCATION
#define MEM_LOCATION "SoC ROM/RAM"
#endif

typedef signed short   ee_s16;
typedef unsigned short ee_u16;
typedef signed int     ee_s32;
typedef double         ee_f32;
typedef unsigned char  ee_u8;
typedef unsigned int   ee_u32;

#if __riscv_xlen == 64
typedef unsigned long ee_ptr_int;
#else
typedef ee_u32 ee_ptr_int;
#endif

typedef size_t ee_size_t;

#ifndef NULL
#define NULL ((void *)0)
#endif

#define align_mem(x) (void *)(4 + (((ee_ptr_int)(x)-1) & ~3))

#define CORETIMETYPE ee_u32
typedef ee_u32 CORE_TICKS;

#ifndef SEED_METHOD
#define SEED_METHOD SEED_VOLATILE
#endif

#ifndef MEM_METHOD
#define MEM_METHOD MEM_STATIC
#endif

#ifndef MULTITHREAD
#define MULTITHREAD 1
#define USE_PTHREAD 0
#define USE_FORK    0
#define USE_SOCKET  0
#endif

#ifndef MAIN_HAS_NOARGC
#define MAIN_HAS_NOARGC 1
#endif

#ifndef MAIN_HAS_NORETURN
#define MAIN_HAS_NORETURN 0
#endif

#ifndef YH_COREMARK_TIMER_HZ
/*
 * Smoke runs use a coarse default timer rate for readable integer seconds.
 * Submission-grade reports pass the real core clock (for example 100000000UL)
 * and parse raw ticks on the host because HAS_FLOAT=0 truncates in-program
 * seconds/Iterations-Sec output.
 */
#define YH_COREMARK_TIMER_HZ 1000UL
#endif

#define CLOCKS_PER_SEC             YH_COREMARK_TIMER_HZ
#define TIMER_RES_DIVIDER          1
#define SAMPLE_TIME_IMPLEMENTATION 1
#define EE_TICKS_PER_SEC           (CLOCKS_PER_SEC / TIMER_RES_DIVIDER)
#define PARALLEL_METHOD            "None"

extern ee_u32 default_num_contexts;

typedef struct CORE_PORTABLE_S
{
    ee_u8 portable_id;
} core_portable;

void portable_init(core_portable *p, int *argc, char *argv[]);
void portable_fini(core_portable *p);
void *portable_malloc(ee_size_t size);
void portable_free(void *p);

#if !defined(PROFILE_RUN) && !defined(PERFORMANCE_RUN) \
    && !defined(VALIDATION_RUN)
#if (TOTAL_DATA_SIZE == 1200)
#define PROFILE_RUN 1
#elif (TOTAL_DATA_SIZE == 2000)
#define PERFORMANCE_RUN 1
#else
#define VALIDATION_RUN 1
#endif
#endif

int ee_printf(const char *fmt, ...);

#endif
